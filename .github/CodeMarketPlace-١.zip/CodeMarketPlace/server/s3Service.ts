import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { log } from "./vite";
import crypto from "crypto";
import path from "path";

// S3 client with AWS credentials from environment variables
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ""
  }
});

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME || "";

// Upload a file to S3
export async function uploadFile(fileBuffer: Buffer, fileName: string, mimeType: string): Promise<string> {
  if (!isS3Configured()) {
    throw new Error("S3 is not configured. Please check your environment variables.");
  }
  
  if (!fileBuffer || fileBuffer.length === 0) {
    throw new Error("Invalid file buffer provided");
  }
  
  // Sanitize file name to ensure it's safe for S3
  const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
  
  // Generate a unique file name to prevent overwriting
  const uniqueFileName = generateUniqueFileName(sanitizedFileName);
  
  try {
    // Ensure we have a valid MIME type
    const contentType = mimeType || 'application/octet-stream';
    
    // Upload the file to S3
    const uploadParams = {
      Bucket: BUCKET_NAME,
      Key: uniqueFileName,
      Body: fileBuffer,
      ContentType: contentType,
      CacheControl: 'max-age=31536000' // Cache for 1 year
    };
    
    await s3Client.send(new PutObjectCommand(uploadParams));
    log(`File uploaded successfully to S3: ${uniqueFileName}`, "s3Service");
    
    // Return the file's key (name) in S3
    return uniqueFileName;
  } catch (error: any) {
    log(`Error uploading file to S3: ${error.message}`, "s3Service");
    // Provide more detailed error message
    if (error.code === 'NoSuchBucket') {
      throw new Error(`Bucket ${BUCKET_NAME} does not exist`);
    } else if (error.code === 'AccessDenied') {
      throw new Error('Access denied to S3 bucket. Check your AWS credentials and permissions');
    } else {
      throw new Error(`Failed to upload file to S3: ${error.message}`);
    }
  }
}

// Generate a presigned URL for a file in S3
export async function generatePresignedUrl(key: string, expiresIn = 3600): Promise<string> {
  if (!isS3Configured()) {
    throw new Error("S3 is not configured. Please check your environment variables.");
  }
  
  if (!key) {
    throw new Error("No file key provided for generating presigned URL");
  }
  
  // Validate expiration time - ensure it's not too long
  const maxExpiresIn = 604800; // 7 days, which is the maximum allowed by AWS
  const validExpiresIn = Math.min(expiresIn, maxExpiresIn);
  
  try {
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key
    });
    
    // Get a presigned URL that expires after the specified time (default: 1 hour)
    const url = await getSignedUrl(s3Client, command, { expiresIn: validExpiresIn });
    
    log(`Generated presigned URL for ${key} that expires in ${validExpiresIn} seconds`, "s3Service");
    return url;
  } catch (error: any) {
    log(`Error generating presigned URL: ${error.message}`, "s3Service");
    if (error.code === 'NoSuchKey') {
      throw new Error(`File ${key} does not exist in the S3 bucket`);
    } else if (error.code === 'AccessDenied') {
      throw new Error('Access denied to S3 bucket. Check your AWS credentials and permissions');
    } else {
      throw new Error(`Failed to generate download URL: ${error.message}`);
    }
  }
}

// Delete a file from S3
export async function deleteFile(key: string): Promise<void> {
  if (!isS3Configured()) {
    throw new Error("S3 is not configured. Please check your environment variables.");
  }
  
  if (!key) {
    throw new Error("No file key provided for deletion");
  }
  
  try {
    const deleteParams = {
      Bucket: BUCKET_NAME,
      Key: key
    };
    
    await s3Client.send(new DeleteObjectCommand(deleteParams));
    log(`File deleted successfully from S3: ${key}`, "s3Service");
  } catch (error: any) {
    log(`Error deleting file from S3: ${error.message}`, "s3Service");
    if (error.code === 'NoSuchKey') {
      // If the file doesn't exist, we consider the deletion successful
      log(`File ${key} not found in S3, considering deletion successful`, "s3Service");
      return;
    } else if (error.code === 'AccessDenied') {
      throw new Error('Access denied to S3 bucket. Check your AWS credentials and permissions');
    } else {
      throw new Error(`Failed to delete file from S3: ${error.message}`);
    }
  }
}

// Generate a unique file name to prevent collisions in the bucket
function generateUniqueFileName(originalName: string): string {
  const timestamp = Date.now();
  const randomString = crypto.randomBytes(8).toString("hex");
  const extension = path.extname(originalName);
  const baseName = path.basename(originalName, extension);
  
  return `${baseName}-${timestamp}-${randomString}${extension}`;
}

// Check if S3 credentials are configured
export function isS3Configured(): boolean {
  return (
    !!process.env.AWS_ACCESS_KEY_ID &&
    !!process.env.AWS_SECRET_ACCESS_KEY &&
    !!process.env.AWS_REGION &&
    !!BUCKET_NAME
  );
}

// Get a public URL for an asset (useful for images that don't need presigned URLs)
export function getPublicFileUrl(key: string): string {
  return `https://${BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
}