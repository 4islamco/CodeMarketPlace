import { ReactNode, useState } from "react";
import { SidebarNav } from "./sidebar-nav";
import { MobileNav } from "./mobile-nav";
import { SearchBar } from "./search-bar";
import { Link, useLocation } from "wouter";
import { Bell, Search, ShoppingCart, LogOut } from "lucide-react";
import { AssetWithDetails } from "@shared/schema";
import { AssetPreviewModal } from "./asset-preview-modal";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/authContext";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const [, setLocation] = useLocation();
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<AssetWithDetails | null>(null);
  const { user, isAuthenticated, logout } = useAuth();
  const { toast } = useToast();

  const handleSearch = (query: string) => {
    setLocation(`/search?q=${encodeURIComponent(query)}`);
    setIsSearchExpanded(false);
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Error logging out",
        description: "There was a problem logging out of your account",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex flex-col h-screen lg:flex-row">
      <SidebarNav />

      <main className="flex-1 overflow-y-auto bg-dark-800">
        {/* Top Navigation Bar */}
        <header className="sticky top-0 z-30 bg-dark-800 border-b border-dark-700 shadow-sm">
          <div className="container mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center lg:hidden">
              <div className="h-9 w-9 rounded-lg primary-gradient flex items-center justify-center mr-2">
                <i className="ri-store-2-line text-white text-lg"></i>
              </div>
              <h1 className="text-lg font-bold text-white">CreatorHub</h1>
            </div>
            
            <div className="relative w-full max-w-xl mx-4 hidden md:block">
              <SearchBar onSearch={handleSearch} />
            </div>
            
            <div className="flex items-center">
              {isSearchExpanded ? (
                <div className="fixed inset-0 bg-dark-800/95 z-50 p-4 md:hidden">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-white font-medium">Search</h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsSearchExpanded(false)}
                      className="text-gray-400"
                    >
                      <i className="ri-close-line text-xl"></i>
                    </Button>
                  </div>
                  <SearchBar 
                    onSearch={(query) => {
                      handleSearch(query);
                      setIsSearchExpanded(false);
                    }}
                  />
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="icon"
                  className="p-2 rounded-full hover:bg-dark-700 text-gray-400 md:hidden"
                  onClick={() => setIsSearchExpanded(true)}
                >
                  <Search className="h-5 w-5" />
                </Button>
              )}
              {isAuthenticated && (
                <Link href="/cart">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-2 p-2 rounded-full hover:bg-dark-700 text-gray-400"
                  >
                    <ShoppingCart className="h-5 w-5" />
                  </Button>
                </Link>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="ml-2 p-2 rounded-full hover:bg-dark-700 text-gray-400"
              >
                <Bell className="h-5 w-5" />
              </Button>
              
              {isAuthenticated && user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="ml-3 relative cursor-pointer">
                      <img
                        className="h-9 w-9 rounded-full object-cover border-2 border-primary"
                        src={user.avatarUrl || "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"}
                        alt={user.displayName || user.username}
                      />
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>{user.displayName || user.username}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/profile">Profile</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/purchases">My Purchases</Link>
                    </DropdownMenuItem>
                    {user.isCreator && (
                      <DropdownMenuItem asChild>
                        <Link href="/creator-dashboard">Creator Dashboard</Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem asChild>
                      <Link href="/settings">Settings</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center ml-2">
                  <Link href="/login">
                    <Button variant="ghost" size="sm" className="text-white hover:bg-primary/20">
                      Log in
                    </Button>
                  </Link>
                  <Link href="/signup">
                    <Button size="sm" className="ml-2">
                      Sign up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="container mx-auto px-4 py-6 pb-20 lg:pb-6">
          {children}
        </div>

        <MobileNav />
      </main>

      {/* Asset Preview Modal */}
      <AssetPreviewModal
        asset={selectedAsset}
        isOpen={!!selectedAsset}
        onClose={() => setSelectedAsset(null)}
      />
    </div>
  );
}
