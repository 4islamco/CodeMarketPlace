import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Function to get CSRF token from cookie
function getCsrfToken(): string | null {
  const cookies = document.cookie.split(';');
  for (let i = 0; i < cookies.length; i++) {
    const cookie = cookies[i].trim();
    if (cookie.startsWith('XSRF-TOKEN=')) {
      return cookie.substring('XSRF-TOKEN='.length, cookie.length);
    }
  }
  return null;
}

// URL validation function
function validateAndSanitizeUrl(url: string): string {
  // Ensure URL starts with a slash for API endpoints
  if (!url.startsWith('/api/')) {
    // If it's an absolute URL, make sure it's from our domain
    if (url.startsWith('http')) {
      const allowedDomains = [
        window.location.origin,
        'http://localhost:5000',
        'https://yourproductiondomain.com'
      ];
      
      const urlObj = new URL(url);
      const origin = urlObj.origin;
      
      if (!allowedDomains.includes(origin)) {
        throw new Error('Invalid URL: domain not allowed');
      }
      
      // URL is valid, return it
      return url;
    } else {
      // Prepend with /api/ if missing
      return `/api/${url.startsWith('/') ? url.substring(1) : url}`;
    }
  }
  
  // URL already starts with /api/, return it
  return url;
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  try {
    // Validate and sanitize URL
    const validatedUrl = validateAndSanitizeUrl(url);
    
    // Get CSRF token
    const csrfToken = getCsrfToken();
    
    // Set headers including CSRF token if available
    const headers: Record<string, string> = {
      ...(data ? { "Content-Type": "application/json" } : {}),
      ...(csrfToken ? { "X-CSRF-Token": csrfToken } : {})
    };
    
    const res = await fetch(validatedUrl, {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include", // Include cookies for authentication
    });

    await throwIfResNotOk(res);
    return res;
  } catch (error) {
    console.error('API Request Error:', error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      // Validate URL first
      const url = validateAndSanitizeUrl(queryKey[0] as string);
      
      // Get CSRF token
      const csrfToken = getCsrfToken();
      
      // Set headers including CSRF token if available
      const headers: Record<string, string> = {
        ...(csrfToken ? { "X-CSRF-Token": csrfToken } : {})
      };
      
      const res = await fetch(url, {
        credentials: "include",
        headers
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }

      await throwIfResNotOk(res);
      return await res.json();
    } catch (error) {
      console.error('Query Error:', error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: import.meta.env.PROD, // Only refetch in production
      staleTime: 1000 * 60 * 5, // 5 minutes - more reasonable stale time
      retry: 1, // Retry once on failure
      networkMode: 'always', // Always try network requests even if offline
    },
    mutations: {
      retry: 1, // Retry once on failure
      networkMode: 'always',
      onError: (error) => {
        console.error('Mutation error:', error);
        // You can add global error handling here if needed
      },
    },
  },
});
