# CreatorHub - Digital Asset Marketplace

A modern, secure marketplace platform for buying and selling digital assets with creator profiles, secure payments via Stripe, S3 file storage, and comprehensive user rating system.

![CreatorHub](https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=400)

## Features

- **Browse & Discover:** Explore digital assets across multiple categories with advanced search and filtering
- **Creator Profiles:** Showcase your work, build your brand, and track sales metrics
- **Asset Preview:** See detailed previews with thumbnails before purchasing
- **Secure Payments:** Integrated Stripe payment processing with webhooks and secure checkout flow
- **Shopping Cart:** Add items to cart and complete purchases with a streamlined checkout experience
- **User Dashboard:** Manage purchased assets, download history, and favorite collections
- **Rating System:** Rate and review purchased assets to help other buyers
- **Secure File Storage:** AWS S3 integration for secure asset uploads and time-limited downloads
- **Security Features:** 
  - Password encryption with bcrypt
  - CSRF protection
  - Rate limiting to prevent abuse
  - Helmet for secure HTTP headers
  - Input validation and URL sanitization
  - Secure authentication with session management
- **Comprehensive API Documentation:** Interactive Swagger documentation for all endpoints

## Tech Stack

- **Frontend:**
  - React 18+ with TypeScript
  - Modern React patterns with hooks and context
  - Responsive design with mobile-first approach
  
- **State Management & Data Fetching:**
  - TanStack React Query for efficient data fetching and caching
  - Optimized to prevent N+1 query problems
  - Context API for global state management

- **UI/UX:**
  - Tailwind CSS for utility-based styling
  - Shadcn UI components library for consistent design
  - Dark mode with custom color scheme
  - Responsive layouts for all device sizes
  
- **Backend:**
  - Node.js with Express
  - RESTful API architecture
  - Modular route handling and middleware
  
- **Database:**
  - PostgreSQL for production data
  - Drizzle ORM for type-safe database operations
  - Well-structured relations and efficient queries
  - Fallback to in-memory storage for development
  
- **Storage:**
  - AWS S3 integration for secure file storage
  - Presigned URLs for time-limited, secure downloads
  - Efficient file handling and optimization
  
- **Authentication:**
  - Secure cookie-based sessions with express-session
  - Password hashing with bcrypt
  - Role-based access control for creators, buyers, and admins
  
- **Payments:**
  - Stripe integration for secure payment processing
  - Payment intents with client-side confirmation
  - Webhook handling for successful payments

## Setup & Installation

### Prerequisites

- Node.js (v18+)
- npm or yarn
- PostgreSQL database (optional, falls back to in-memory storage)
- AWS S3 bucket for file storage (optional, but required for file uploads/downloads)
- Stripe account for payment processing (optional, but required for checkout functionality)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/creatorhub.git
cd creatorhub
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory with the following variables:

```
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/creatorhub
PGHOST=localhost
PGPORT=5432
PGUSER=user
PGPASSWORD=password
PGDATABASE=creatorhub

# Session Configuration
SESSION_SECRET=your_session_secret_here

# AWS S3 Configuration
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=us-east-1
AWS_S3_BUCKET_NAME=your-bucket-name

# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=pk_test_your_stripe_public_key
```

4. Run database migrations:
```bash
npm run db:push
```

5. Start the development server:
```bash
npm run dev
```

6. Open your browser and navigate to `http://localhost:5000`

### Environment Variable Details

#### Required
- `DATABASE_URL`: Connection string for PostgreSQL database
- `SESSION_SECRET`: Secret key for session encryption

#### Optional but recommended for full functionality
- AWS S3 Configuration (required for file uploads and downloads):
  - `AWS_ACCESS_KEY_ID`: Your AWS access key
  - `AWS_SECRET_ACCESS_KEY`: Your AWS secret key
  - `AWS_REGION`: AWS region (e.g., us-east-1)
  - `AWS_S3_BUCKET_NAME`: Name of your S3 bucket
  
- Stripe Configuration (required for payments):
  - `STRIPE_SECRET_KEY`: Your Stripe secret key (starts with sk_)
  - `VITE_STRIPE_PUBLIC_KEY`: Your Stripe publishable key (starts with pk_)

## User Guide

### For Buyers

1. **Browse Assets:** Explore categories or use the search function to find digital assets
2. **View Details:** Click on assets to see detailed information, previews, and user ratings
3. **Create Account:** Sign up to save favorites and make purchases
4. **Add to Cart:** Add desired items to your shopping cart for checkout
5. **Purchase:** Complete the checkout process using Stripe's secure payment system
6. **Download:** Access your purchased items from your profile dashboard
7. **Rate Assets:** Leave ratings and reviews for assets you've purchased to help others

### For Creators

1. **Become a Creator:** Sign up and select "creator account" option during registration
2. **Set Up Profile:** Add your bio, profile picture, and portfolio details to showcase your brand
3. **Upload Assets:** Add your digital products with descriptions, previews, and file uploads
4. **Set Pricing:** Determine the price points for your work that maximize value and sales
5. **Track Sales:** Monitor your performance, sales metrics, and customer reviews in the creator dashboard
6. **Manage Assets:** Update existing assets or add new ones as your portfolio grows
7. **Respond to Reviews:** Engage with customer feedback to improve your products

## Project Structure

```
├── client/                # Frontend application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utility libraries
│   │   ├── pages/         # Application views
│   │   └── App.tsx        # Main application component
│
├── server/                # Backend application
│   ├── auth.ts            # Authentication logic
│   ├── routes.ts          # API endpoints
│   ├── storage.ts         # Database operations
│   └── index.ts           # Server entry point
│
└── shared/                # Shared code between client and server
    └── schema.ts          # Data models and validation
```

## API Documentation

CreatorHub provides comprehensive API documentation through Swagger UI, available at the `/api-docs` endpoint when running the application. The API follows RESTful conventions with the following main endpoint groups:

### Authentication
- `POST /api/auth/signup` - Create a new user account
- `POST /api/auth/login` - Log in a user
- `GET /api/auth/me` - Get current user information
- `POST /api/auth/logout` - Log out current user

### Users & Creators
- `GET /api/users/:id` - Get user details
- `GET /api/creators` - Get list of creators
- `POST /api/users` - Create a new user

### Categories
- `GET /api/categories` - List all categories
- `GET /api/categories/:id` - Get category details
- `POST /api/categories` - Create new category (admin only)

### Assets
- `GET /api/assets` - List assets (with filters: limit, categoryId, creatorId)
- `GET /api/assets/:id` - Get asset details
- `GET /api/assets/featured` - Get featured assets
- `GET /api/assets/recent` - Get recently added assets
- `GET /api/assets/trending` - Get trending assets
- `GET /api/assets/search` - Search assets by query
- `POST /api/assets` - Create new asset (creator only)
- `POST /api/assets/with-file` - Create new asset with file upload

### Cart & Purchases
- `GET /api/cart` - Get user's cart
- `POST /api/cart` - Add item to cart
- `DELETE /api/cart/:itemId` - Remove item from cart
- `DELETE /api/cart` - Clear cart
- `GET /api/purchases` - Get user's purchases
- `POST /api/purchases/checkout` - Process checkout of cart items
- `GET /api/purchases/:id` - Get purchase details
- `GET /api/purchases/asset/:assetId` - Check if asset is purchased

### Ratings
- `GET /api/ratings/asset/:assetId` - Get ratings for an asset
- `GET /api/ratings/user` - Get ratings by the current user
- `GET /api/ratings/user/asset/:assetId` - Get user's rating for an asset
- `POST /api/ratings` - Create or update a rating
- `DELETE /api/ratings/:ratingId` - Delete a rating

### Payments
- `POST /api/create-payment-intent` - Create Stripe payment intent
- `GET /api/download-asset/:paymentIntentId` - Get asset after payment
- `POST /api/stripe-webhook` - Handle Stripe webhook events

### File Upload/Download
- `POST /api/upload` - Upload a file to S3
- `GET /api/assets/:id/download-url` - Get presigned download URL for purchased asset

## Security Considerations

The application implements several security measures to protect user data and ensure secure operations:

- **Password Security**: All passwords are hashed using bcrypt before storage
- **Session Management**: Secure cookies with HTTP-only flag
- **CSRF Protection**: Token-based protection against cross-site request forgery
- **Rate Limiting**: Prevents abuse through excessive API requests
- **Input Validation**: All user inputs are validated before processing
- **URL Validation**: URLs are validated to prevent malicious redirects
- **HTTP Security Headers**: Implemented using Helmet middleware
- **Secure File Downloads**: Time-limited presigned URLs for asset downloads
- **Payment Security**: All payment processing handled by Stripe's secure infrastructure

## Deployment

For production deployment, follow these additional steps:

1. **Set Production Environment Variables**:
   - Set `NODE_ENV=production`
   - Use strong, unique secrets for all encryption keys
   - Configure CORS for your production domain

2. **Database Considerations**:
   - Use a managed PostgreSQL service for better scalability
   - Set up regular database backups
   - Consider read replicas for high traffic

3. **S3 Configuration**:
   - Configure proper CORS settings on your S3 bucket
   - Set up appropriate bucket policies
   - Consider using a CDN for improved asset delivery

4. **Stripe Setup**:
   - Use production API keys for Stripe
   - Configure webhook endpoints properly
   - Implement additional fraud protection measures

5. **Monitoring & Logging**:
   - Set up application monitoring
   - Implement comprehensive error logging
   - Configure alerts for critical failures

## License

This project is licensed under the MIT License - see the LICENSE file for details.