import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';

const options: swaggerJSDoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CreatorHub Marketplace API',
      version: '1.0.0',
      description: 'API documentation for CreatorHub Digital Asset Marketplace',
      contact: {
        name: 'API Support',
        email: 'support@creatorhub.com'
      },
    },
    servers: [
      {
        url: '/api',
        description: 'Development server'
      }
    ],
    components: {
      securitySchemes: {
        sessionAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'connect.sid',
          description: 'Session cookie for authenticated requests'
        }
      }
    },
    tags: [
      {
        name: 'Auth',
        description: 'Authentication endpoints'
      },
      {
        name: 'Users',
        description: 'User management'
      },
      {
        name: 'Categories',
        description: 'Asset categories'
      },
      {
        name: 'Assets',
        description: 'Digital assets'
      },
      {
        name: 'Cart',
        description: 'Shopping cart operations'
      },
      {
        name: 'Purchases',
        description: 'Purchase history and checkout'
      },
      {
        name: 'Ratings',
        description: 'User ratings and reviews'
      },
      {
        name: 'Files',
        description: 'File uploads and downloads'
      },
      {
        name: 'Payments',
        description: 'Payment processing with Stripe'
      }
    ]
  },
  apis: ['./server/swagger/*.yaml'] // Path to API docs
};

const swaggerSpec = swaggerJSDoc(options);

export function setupSwagger(app: Express): void {
  // Serve swagger UI
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  
  // Serve swagger spec as JSON endpoint
  app.get('/api-docs.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(swaggerSpec);
  });
}