import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertAssetSchema, insertCategorySchema, insertUserSchema } from "@shared/schema";
import { log } from "./vite";
import { login, signup, getCurrentUser, logout, authMiddleware } from "./auth";
import session from "express-session";
import Stripe from "stripe";
import multer from "multer";
import { 
  uploadFile, 
  generatePresignedUrl, 
  isS3Configured, 
  getPublicFileUrl 
} from "./s3Service";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure multer for file uploads
  const memoryStorage = multer.memoryStorage();
  const upload = multer({ 
    storage: memoryStorage,
    limits: {
      fileSize: 50 * 1024 * 1024, // 50MB file size limit
    }
  });
  // Configure session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "creatorhub-marketplace-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        httpOnly: true,
        sameSite: 'strict' // Prevent CSRF attacks
      },
    })
  );
  
  // Input validation middleware
  app.use((req: Request, res: Response, next: NextFunction) => {
    // Validate URL parameters for numeric IDs
    if (req.params.id && !/^\d+$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid parameter format' });
    }
    
    // Validate query parameters for numeric values
    const numericParams = ['limit', 'categoryId', 'creatorId'];
    for (const param of numericParams) {
      if (req.query[param] && !/^\d+$/.test(req.query[param] as string)) {
        return res.status(400).json({ error: `Invalid query parameter: ${param}` });
      }
    }
    
    next();
  });
  
  // General error handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    if (err) {
      log(`API Error: ${err.message}`, "routes");
      return res.status(500).json({ error: 'Server error', message: err.message });
    }
    
    return next();
  });

  // Authentication routes
  app.post("/api/auth/login", login);
  app.post("/api/auth/signup", signup);
  app.get("/api/auth/me", getCurrentUser);
  app.post("/api/auth/logout", logout);

  // API Routes

  // User routes
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send password to client
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Don't send password to client
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  app.get("/api/creators", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const creators = await storage.getCreators(limit);
    
    // Don't send passwords to client
    const creatorsWithoutPasswords = creators.map(creator => {
      const { password, ...creatorWithoutPassword } = creator;
      return creatorWithoutPassword;
    });
    
    res.json(creatorsWithoutPasswords);
  });

  // Category routes
  app.get("/api/categories", async (_req: Request, res: Response) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });
  
  app.get("/api/categories/:id", async (req: Request, res: Response) => {
    const categoryId = parseInt(req.params.id);
    
    if (isNaN(categoryId)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const category = await storage.getCategoryById(categoryId);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    res.json(category);
  });
  
  app.post("/api/categories", async (req: Request, res: Response) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Asset routes
  app.get("/api/assets", async (req: Request, res: Response) => {
    const {
      limit,
      categoryId,
      creatorId,
      featured
    } = req.query;
    
    const options = {
      limit: limit ? parseInt(limit as string) : undefined,
      categoryId: categoryId ? parseInt(categoryId as string) : undefined,
      creatorId: creatorId ? parseInt(creatorId as string) : undefined,
      featured: featured ? featured === 'true' : undefined
    };
    
    const assets = await storage.getAssets(options);
    res.json(assets);
  });
  
  app.get("/api/assets/featured", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const featuredAssets = await storage.getFeaturedAssets(limit);
    res.json(featuredAssets);
  });
  
  app.get("/api/assets/recent", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const recentAssets = await storage.getRecentAssets(limit);
    res.json(recentAssets);
  });
  
  app.get("/api/assets/trending", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const trendingAssets = await storage.getTrendingAssets(limit);
    res.json(trendingAssets);
  });
  
  app.get("/api/assets/search", async (req: Request, res: Response) => {
    const query = req.query.q as string;
    
    if (!query) {
      return res.status(400).json({ message: "Search query is required" });
    }
    
    const searchResults = await storage.searchAssets(query);
    res.json(searchResults);
  });
  
  app.get("/api/assets/:id", async (req: Request, res: Response) => {
    const assetId = parseInt(req.params.id);
    
    if (isNaN(assetId)) {
      return res.status(400).json({ message: "Invalid asset ID" });
    }
    
    const asset = await storage.getAssetById(assetId);
    
    if (!asset) {
      return res.status(404).json({ message: "Asset not found" });
    }
    
    res.json(asset);
  });
  
  // Create an asset without file (basic asset creation)
  app.post("/api/assets", authMiddleware, async (req: Request, res: Response) => {
    try {
      // @ts-ignore - user is set by authMiddleware
      const user = req.user;
      
      // Check if user is a creator
      if (!user.isCreator) {
        return res.status(403).json({ 
          message: "Only creators can publish assets" 
        });
      }
      
      const assetData = insertAssetSchema.parse(req.body);
      
      // Set creatorId to current user's ID
      const assetWithCreator = {
        ...assetData,
        creatorId: user.id
      };
      
      const asset = await storage.createAsset(assetWithCreator);
      res.status(201).json(asset);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid asset data", errors: error.errors });
      }
      log(`Error creating asset: ${error}`, "routes");
      res.status(500).json({ message: "Failed to create asset" });
    }
  });
  
  // Create an asset with file upload (complete asset creation)
  app.post("/api/assets/with-file", authMiddleware, upload.single('file'), async (req: Request, res: Response) => {
    try {
      // @ts-ignore - user is set by authMiddleware
      const user = req.user;
      
      // Check if user is a creator
      if (!user.isCreator) {
        return res.status(403).json({ 
          message: "Only creators can publish assets" 
        });
      }
      
      // Check if file is uploaded
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Parse asset data from the form
      const assetData = JSON.parse(req.body.assetData);
      
      // Validate asset data
      const validatedData = insertAssetSchema.parse(assetData);
      
      const file = req.file;
      
      // Check if AWS S3 is configured
      if (isS3Configured()) {
        // Upload file to S3
        const s3ObjectKey = await uploadFile(
          file.buffer,
          file.originalname,
          file.mimetype
        );
        
        // Generate a public URL for the file
        const fileUrl = getPublicFileUrl(s3ObjectKey);
        
        // Create asset with file information
        const assetWithFile = {
          ...validatedData,
          creatorId: user.id,
          fileUrl,
          fileType: file.mimetype,
          fileSize: file.size,
          s3ObjectKey
        };
        
        const asset = await storage.createAsset(assetWithFile);
        res.status(201).json(asset);
      } else {
        // S3 not configured, create asset without file information
        log("S3 not configured, creating asset without file", "routes");
        
        const assetWithCreator = {
          ...validatedData,
          creatorId: user.id
        };
        
        const asset = await storage.createAsset(assetWithCreator);
        res.status(201).json(asset);
      }
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid asset data", errors: error.errors });
      }
      log(`Error creating asset with file: ${error.message}`, "routes");
      res.status(500).json({ message: "Failed to create asset", error: error.message });
    }
  });

  // Initialize Stripe
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: '2023-10-16' as any, // Use latest API version
  });

  // Create a payment intent endpoint
  app.post("/api/create-payment-intent", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { assetId, amount, currency = 'usd' } = req.body;
      
      if (!assetId || !amount) {
        return res.status(400).json({ message: "Asset ID and amount are required" });
      }
      
      // Get the asset to verify it exists and the price
      const asset = await storage.getAssetById(assetId);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      // Get the price in cents (Stripe requires amounts in smallest currency unit)
      const amountInCents = Math.round(asset.price * 100);
      
      // Create a payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency,
        metadata: {
          assetId: assetId.toString(),
          userId: req.user.id.toString()
        },
        // We can customize this to include more information about the asset
        description: `Purchase of ${asset.title}`,
      });
      
      // Return client secret to the frontend
      res.status(200).json({
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id
      });
    } catch (error: any) {
      log(`Error creating payment intent: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to create payment intent",
        error: error.message 
      });
    }
  });
  
  // Generate a secure download link after successful payment
  app.get("/api/download-asset/:paymentIntentId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { paymentIntentId } = req.params;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Payment Intent ID is required" });
      }
      
      // Verify the payment with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: "Payment not completed" });
      }
      
      // Get the asset ID from the payment metadata
      const assetId = parseInt(paymentIntent.metadata.assetId);
      
      if (isNaN(assetId)) {
        return res.status(400).json({ message: "Invalid asset ID in payment" });
      }
      
      // Get the asset to verify it exists
      const asset = await storage.getAssetById(assetId);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      // Generate a secure, time-limited download token (in a real app, this would be more secure)
      const downloadToken = Buffer.from(`${assetId}-${Date.now()}-${req.user.id}`).toString('base64');
      
      // Return the download URL with the token
      res.status(200).json({
        downloadUrl: `/api/assets/download/${assetId}?token=${downloadToken}`,
        asset: {
          id: asset.id,
          title: asset.title,
          previewUrl: asset.previewUrl
        }
      });
    } catch (error: any) {
      log(`Error generating download link: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to generate download link",
        error: error.message 
      });
    }
  });
  
  // Asset download endpoint with token verification
  app.get("/api/assets/download/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.status(401).json({ message: "Invalid download token" });
      }
      
      // Verify the download token (in a real app, this would be more secure)
      // For example, store tokens in a database with expiration
      const tokenData = Buffer.from(token, 'base64').toString();
      const [tokenAssetId, timestamp, userId] = tokenData.split('-');
      
      if (parseInt(tokenAssetId) !== assetId || parseInt(userId) !== req.user.id) {
        return res.status(401).json({ message: "Invalid download token" });
      }
      
      // Check if token is expired (24 hours)
      const tokenTime = parseInt(timestamp);
      const now = Date.now();
      const tokenAge = now - tokenTime;
      const maxAge = 24 * 60 * 60 * 1000; // 24 hours
      
      if (tokenAge > maxAge) {
        return res.status(401).json({ message: "Download token expired" });
      }
      
      // Get the asset
      const asset = await storage.getAssetById(assetId);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      // In a real application, you would serve the actual file here
      // For this demo, we'll just return a success message with the download URL
      res.status(200).json({
        message: "Download authorized",
        downloadUrl: asset.fileUrl,
        asset: {
          id: asset.id,
          title: asset.title,
          fileType: asset.fileType
        }
      });
    } catch (error: any) {
      log(`Error downloading asset: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to download asset",
        error: error.message 
      });
    }
  });
  
  // Webhook endpoint to handle Stripe events
  app.post("/api/stripe-webhook", async (req: Request, res: Response) => {
    const signature = req.headers['stripe-signature'] as string;
    
    try {
      // In a production environment, you should use a webhook secret
      // This would require raw body parsing, see Stripe documentation
      const event = req.body;
      
      // Handle different event types
      switch (event.type) {
        case 'payment_intent.succeeded':
          const paymentIntent = event.data.object;
          log(`Payment succeeded: ${paymentIntent.id}`, "stripe-webhook");
          // Here you would update your database to mark the purchase as complete
          break;
        case 'payment_intent.payment_failed':
          const failedPayment = event.data.object;
          log(`Payment failed: ${failedPayment.id}`, "stripe-webhook");
          // Handle failed payment
          break;
        default:
          log(`Unhandled event type: ${event.type}`, "stripe-webhook");
      }
      
      res.status(200).json({ received: true });
    } catch (error: any) {
      log(`Webhook error: ${error.message}`, "stripe-webhook");
      res.status(400).json({ message: `Webhook Error: ${error.message}` });
    }
  });
  
  // File upload endpoint for S3
  app.post("/api/upload", authMiddleware, upload.single('file'), async (req: Request, res: Response) => {
    try {
      // Check if user is authorized to upload
      if (!req.user.isCreator) {
        return res.status(403).json({ 
          message: "Only creators can upload files" 
        });
      }
      
      // Check if file is uploaded
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Check if AWS S3 is configured
      if (!isS3Configured()) {
        return res.status(503).json({ 
          message: "File storage service is not configured properly" 
        });
      }
      
      const file = req.file;
      
      // Upload file to S3
      const s3ObjectKey = await uploadFile(
        file.buffer,
        file.originalname,
        file.mimetype
      );
      
      // Generate a public URL for the file
      const fileUrl = getPublicFileUrl(s3ObjectKey);
      
      // Return the file details
      res.status(200).json({
        message: "File uploaded successfully",
        fileUrl,
        fileType: file.mimetype,
        fileName: file.originalname,
        fileSize: file.size,
        s3ObjectKey
      });
    } catch (error: any) {
      log(`Error uploading file: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to upload file",
        error: error.message 
      });
    }
  });
  
  // Get presigned URL for asset download
  app.get("/api/assets/:id/download-url", authMiddleware, async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);
      
      if (isNaN(assetId)) {
        return res.status(400).json({ message: "Invalid asset ID" });
      }
      
      // Get the asset
      const asset = await storage.getAssetById(assetId);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      // Check if S3 is configured
      if (!isS3Configured()) {
        return res.status(503).json({ 
          message: "File storage service is not configured properly" 
        });
      }
      
      // Check if asset has a file URL
      if (!asset.s3ObjectKey) {
        return res.status(404).json({ message: "Asset has no associated file" });
      }
      
      // Generate a presigned URL for the file (expires in 1 hour)
      const presignedUrl = await generatePresignedUrl(asset.s3ObjectKey, 3600);
      
      // Return the presigned URL
      res.status(200).json({
        downloadUrl: presignedUrl,
        fileName: asset.title,
        fileType: asset.fileType,
        expiresIn: 3600 // Seconds
      });
    } catch (error: any) {
      log(`Error generating download URL: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to generate download URL",
        error: error.message 
      });
    }
  });

  // Shopping Cart API Endpoints
  app.get("/api/cart", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const cartItems = await storage.getUserCart(userId);
      
      res.status(200).json(cartItems);
    } catch (error: any) {
      log(`Error getting cart: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get cart",
        error: error.message 
      });
    }
  });
  
  app.post("/api/cart", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const { assetId, quantity = 1 } = req.body;
      
      if (!assetId) {
        return res.status(400).json({ message: "Asset ID is required" });
      }
      
      // Validate asset exists
      const asset = await storage.getAssetById(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      // Add to cart
      const cartItem = await storage.addToCart({
        userId,
        assetId,
        quantity
      });
      
      res.status(200).json(cartItem);
    } catch (error: any) {
      log(`Error adding to cart: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to add to cart",
        error: error.message 
      });
    }
  });
  
  app.delete("/api/cart/:itemId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const itemId = parseInt(req.params.itemId);
      
      if (isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      await storage.removeFromCart(userId, itemId);
      
      res.status(200).json({ message: "Item removed from cart" });
    } catch (error: any) {
      log(`Error removing from cart: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to remove from cart",
        error: error.message 
      });
    }
  });
  
  app.delete("/api/cart", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      await storage.clearCart(userId);
      
      res.status(200).json({ message: "Cart cleared" });
    } catch (error: any) {
      log(`Error clearing cart: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to clear cart",
        error: error.message 
      });
    }
  });
  
  // Purchase API Endpoints
  app.get("/api/purchases", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const purchases = await storage.getUserPurchases(userId);
      
      res.status(200).json(purchases);
    } catch (error: any) {
      log(`Error getting purchases: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get purchases",
        error: error.message 
      });
    }
  });
  
  app.post("/api/purchases/checkout", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Payment Intent ID is required" });
      }
      
      // Verify payment with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: "Payment not completed" });
      }
      
      // Get cart items
      const cartItems = await storage.getUserCart(userId);
      
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }
      
      // Record purchases for each cart item
      const purchases = await Promise.all(cartItems.map(async (item) => {
        const purchase = await storage.recordPurchase({
          userId,
          assetId: item.asset.id,
          amount: item.asset.price,
          paymentIntentId,
          status: "completed"
        });
        
        return purchase;
      }));
      
      // Clear cart after successful purchase
      await storage.clearCart(userId);
      
      // Return the purchases
      res.status(200).json({
        message: "Checkout completed successfully",
        purchases
      });
    } catch (error: any) {
      log(`Error checking out: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to complete checkout",
        error: error.message 
      });
    }
  });
  
  app.get("/api/purchases/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const purchaseId = parseInt(req.params.id);
      
      if (isNaN(purchaseId)) {
        return res.status(400).json({ message: "Invalid purchase ID" });
      }
      
      const purchase = await storage.getPurchaseById(purchaseId);
      
      if (!purchase) {
        return res.status(404).json({ message: "Purchase not found" });
      }
      
      // Verify that the purchase belongs to the current user
      if (purchase.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.status(200).json(purchase);
    } catch (error: any) {
      log(`Error getting purchase: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get purchase",
        error: error.message 
      });
    }
  });
  
  // Check if user has purchased an asset
  app.get("/api/purchases/asset/:assetId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const assetId = parseInt(req.params.assetId);
      
      if (isNaN(assetId)) {
        return res.status(400).json({ message: "Invalid asset ID" });
      }
      
      const isPurchased = await storage.isPurchased(userId, assetId);
      
      res.status(200).json({ purchased: isPurchased });
    } catch (error: any) {
      log(`Error checking purchase status: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to check purchase status",
        error: error.message 
      });
    }
  });
  
  // Ratings API endpoints
  
  // Get all ratings for an asset
  app.get("/api/ratings/asset/:assetId", async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.assetId);
      
      if (isNaN(assetId)) {
        return res.status(400).json({ message: "Invalid asset ID" });
      }
      
      const ratings = await storage.getRatingsByAsset(assetId);
      
      res.status(200).json(ratings);
    } catch (error: any) {
      log(`Error getting asset ratings: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get ratings",
        error: error.message 
      });
    }
  });
  
  // Get all ratings by a user
  app.get("/api/ratings/user", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const ratings = await storage.getRatingsByUser(userId);
      
      res.status(200).json(ratings);
    } catch (error: any) {
      log(`Error getting user ratings: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get ratings",
        error: error.message 
      });
    }
  });
  
  // Get user's rating for a specific asset
  app.get("/api/ratings/user/asset/:assetId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const assetId = parseInt(req.params.assetId);
      
      if (isNaN(assetId)) {
        return res.status(400).json({ message: "Invalid asset ID" });
      }
      
      const rating = await storage.getUserRatingForAsset(userId, assetId);
      
      if (!rating) {
        return res.status(404).json({ message: "Rating not found" });
      }
      
      res.status(200).json(rating);
    } catch (error: any) {
      log(`Error getting user rating for asset: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to get rating",
        error: error.message 
      });
    }
  });
  
  // Create or update a rating
  app.post("/api/ratings", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const { assetId, rating, comment } = req.body;
      
      if (!assetId || !rating) {
        return res.status(400).json({ message: "Asset ID and rating are required" });
      }
      
      // Validate rating value (1-5)
      if (rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }
      
      // Verify that the user has purchased the asset
      const hasPurchased = await storage.isPurchased(userId, assetId);
      
      if (!hasPurchased) {
        return res.status(403).json({ message: "You must purchase this asset before rating it" });
      }
      
      // Create or update the rating
      const createdRating = await storage.createOrUpdateRating({
        userId,
        assetId,
        rating,
        comment
      });
      
      res.status(200).json(createdRating);
    } catch (error: any) {
      log(`Error creating or updating rating: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to create or update rating",
        error: error.message 
      });
    }
  });
  
  // Delete a rating
  app.delete("/api/ratings/:ratingId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = req.user.id;
      const ratingId = parseInt(req.params.ratingId);
      
      if (isNaN(ratingId)) {
        return res.status(400).json({ message: "Invalid rating ID" });
      }
      
      await storage.deleteRating(userId, ratingId);
      
      res.status(200).json({ message: "Rating deleted successfully" });
    } catch (error: any) {
      log(`Error deleting rating: ${error.message}`, "routes");
      res.status(500).json({ 
        message: "Failed to delete rating",
        error: error.message 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
