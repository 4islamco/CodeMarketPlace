import { ratings, type Rating, type InsertRating } from "@shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { log } from "./vite";

// These functions will be added to the PostgreSQL storage class
export async function getRatingsByAsset(this: any, assetId: number): Promise<Rating[]> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    const assetRatings = await db.select()
      .from(ratings)
      .where(eq(ratings.assetId, assetId))
      .orderBy(desc(ratings.createdAt));
    
    return assetRatings;
  } catch (error) {
    log(`Error getting ratings for asset: ${error}`, "storage");
    return [];
  }
}

export async function getRatingsByUser(this: any, userId: number): Promise<Rating[]> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    const userRatings = await db.select()
      .from(ratings)
      .where(eq(ratings.userId, userId))
      .orderBy(desc(ratings.createdAt));
    
    return userRatings;
  } catch (error) {
    log(`Error getting ratings by user: ${error}`, "storage");
    return [];
  }
}

export async function getUserRatingForAsset(this: any, userId: number, assetId: number): Promise<Rating | undefined> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    const result = await db.select()
      .from(ratings)
      .where(
        and(
          eq(ratings.userId, userId),
          eq(ratings.assetId, assetId)
        )
      )
      .limit(1);
    
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    log(`Error getting user rating for asset: ${error}`, "storage");
    return undefined;
  }
}

export async function createOrUpdateRating(this: any, rating: InsertRating): Promise<Rating> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    // Check if user has already rated this asset
    const existingRating = await this.getUserRatingForAsset(rating.userId, rating.assetId);
    
    if (existingRating) {
      // Update existing rating
      const updated = await db.update(ratings)
        .set({ 
          rating: rating.rating, 
          comment: rating.comment,
          updatedAt: new Date()
        })
        .where(eq(ratings.id, existingRating.id))
        .returning();
      
      // Update asset's average rating
      await this.updateAssetRating(rating.assetId);
      
      return updated[0];
    } else {
      // Create new rating
      const newRating = await db.insert(ratings)
        .values(rating)
        .returning();
      
      // Update asset's average rating
      await this.updateAssetRating(rating.assetId);
      
      return newRating[0];
    }
  } catch (error) {
    log(`Error creating or updating rating: ${error}`, "storage");
    throw new Error("Failed to create or update rating");
  }
}

export async function deleteRating(this: any, userId: number, ratingId: number): Promise<void> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    // Get the rating to find the associated asset
    const ratingToDelete = await db.select()
      .from(ratings)
      .where(eq(ratings.id, ratingId))
      .limit(1);
    
    if (ratingToDelete.length === 0) {
      throw new Error("Rating not found");
    }
    
    // Check if the rating belongs to the user
    if (ratingToDelete[0].userId !== userId) {
      throw new Error("Unauthorized to delete this rating");
    }
    
    const assetId = ratingToDelete[0].assetId;
    
    // Delete the rating
    await db.delete(ratings)
      .where(
        and(
          eq(ratings.id, ratingId),
          eq(ratings.userId, userId)
        )
      );
    
    // Update the asset's average rating
    await this.updateAssetRating(assetId);
  } catch (error) {
    log(`Error deleting rating: ${error}`, "storage");
    throw new Error("Failed to delete rating");
  }
}

export async function updateAssetRating(this: any, assetId: number): Promise<void> {
  try {
    const db = this.db;
    if (!db) throw new Error("Database not initialized");
    
    // Calculate average rating for the asset
    const avgRatingResult = await db
      .select({ 
        avgRating: sql`avg(${ratings.rating})::float` 
      })
      .from(ratings)
      .where(eq(ratings.assetId, assetId));
    
    const avgRating = avgRatingResult[0]?.avgRating || 0;
    
    // Update the asset's rating
    await db.update(this.assets)
      .set({ rating: avgRating })
      .where(eq(this.assets.id, assetId));
  } catch (error) {
    log(`Error updating asset rating: ${error}`, "storage");
    throw new Error("Failed to update asset rating");
  }
}