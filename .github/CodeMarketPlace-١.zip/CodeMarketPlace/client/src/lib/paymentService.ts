// Stripe integration for payment processing

import { useToast } from "@/hooks/use-toast";
import { AssetWithDetails } from "@shared/schema";
import { apiRequest } from "./queryClient";
import { loadStripe } from "@stripe/stripe-js";
import { useQueryClient } from "@tanstack/react-query";

// Initialize Stripe with the public key
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'bank';
  last4?: string;
  expiryDate?: string;
  name?: string;
}

export interface PaymentIntent {
  id: string;
  clientSecret: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'succeeded' | 'failed';
  created: Date;
  assetId: number;
}

export async function createPaymentIntent(asset: AssetWithDetails): Promise<PaymentIntent> {
  try {
    // Make a real API call to create a payment intent
    const response = await apiRequest('POST', '/api/create-payment-intent', {
      assetId: asset.id,
      amount: asset.price,
      currency: 'usd'
    });
    
    const data = await response.json();
    
    return {
      id: data.paymentIntentId,
      clientSecret: data.clientSecret,
      amount: asset.price * 100, // In cents
      currency: 'usd',
      status: 'pending',
      created: new Date(),
      assetId: asset.id
    };
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw new Error('Failed to create payment intent');
  }
}

export async function confirmPayment(
  clientSecret: string,
  paymentMethod: { id: string }
): Promise<{success: boolean, downloadUrl?: string}> {
  try {
    const stripe = await stripePromise;
    
    if (!stripe) {
      throw new Error('Stripe failed to load');
    }
    
    const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: paymentMethod.id
    });
    
    if (error) {
      throw new Error(error.message);
    }
    
    if (paymentIntent && paymentIntent.status === 'succeeded') {
      // Payment successful, now get download link from server
      const response = await apiRequest('GET', `/api/download-asset/${paymentIntent.id}`);
      const data = await response.json();
      
      return {
        success: true,
        downloadUrl: data.downloadUrl
      };
    } else {
      throw new Error('Payment not completed');
    }
  } catch (error) {
    console.error('Error processing payment:', error);
    throw error;
  }
}

export function usePayment() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const purchaseAsset = async (asset: AssetWithDetails, paymentMethodId: string) => {
    try {
      // Show processing toast
      toast({
        title: "Initializing payment",
        description: "Please wait while we connect to the payment processor...",
      });
      
      // Create payment intent
      const paymentIntent = await createPaymentIntent(asset);
      
      // Process the payment
      toast({
        title: "Processing payment",
        description: "Please wait while we process your payment...",
      });
      
      // Confirm the payment with Stripe
      const result = await confirmPayment(paymentIntent.clientSecret, { id: paymentMethodId });
      
      if (result.success) {
        // Invalidate user asset queries to refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/user/assets'] });
        
        toast({
          title: "Payment successful!",
          description: `You have successfully purchased ${asset.title}`,
        });
        
        return result.downloadUrl;
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Payment failed",
        description: error.message || "There was a problem processing your payment. Please try again.",
      });
      return null;
    }
  };
  
  return { purchaseAsset };
}